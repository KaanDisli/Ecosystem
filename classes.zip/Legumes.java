public class Legumes extends Perma{
	
	public Legumes(){
		super();
		}
	public int getJours(){return Jours;}

}
