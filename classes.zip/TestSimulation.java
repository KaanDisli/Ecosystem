import java.util.ArrayList;

public class TestSimulation{

	//30x30 limit
	public static  void main(String[] args){
		Simulation s = new Simulation(5,5,10,10);
		//CopySimulation s = new CopySimulation(5,5,10,10);
					
	}

	


}







