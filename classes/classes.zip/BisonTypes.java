public interface BisonTypes{

	int getX();
	int getY();


}
