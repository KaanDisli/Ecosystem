import java.util.ArrayList;

public class TestSimulation{

	//30x30 limit
	public static  void main(String[] args){
		Simulation s = new Simulation(7,8,10,10);
		
					
	}

	


}







