abstract class Perma{
	protected int Jours;
	public void Perma(){

		Jours = 5;
	}
	abstract int getJours();
}
